---
name: character-hair-design
description: "发型设计：发流、体积、轮廓与跨视角连续性"
---

# 发型设计：发流、体积、轮廓与跨视角连续性

读取 [专项交接](../../references/specialist-contract.md)、[群像差异化框架](../../references/differentiation-framework.md) 与本专项知识快照。建立发际、发流、发量、前侧后体积和束发结构；与最相近角色比较发型块面，核对生活方式及背面结构。读取已批准视觉基准、当前设计卡与比较组；输出有依据的 2–3 个可见方案，明确原文事实、创作提案、制作核对点及与近邻的差异。新特征只能作为待选方案，不能代替操作者批准。提交 CharacterSpecialistProposalV1 JSON 与短 Markdown，运行 scripts/validate_specialist_proposal.py；不调用生图。

## Packaged references

- [knowledge/index.md](../../knowledge/index.md)
- [references/specialist-contract.md](../../references/specialist-contract.md)
- [references/differentiation-framework.md](../../references/differentiation-framework.md)
- [references/knowledge/character-hair-design/hair.md](../../references/knowledge/character-hair-design/hair.md)
